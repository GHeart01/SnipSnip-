using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WhiteCloudSpawnerScript : MonoBehaviour
{
    public GameObject Whitecloud;
    public float spawnRate = 4;
    private float timer = 0;
    public float heightOffset = 0;

    // Start is called before the first frame update
    void Start()
    {
        spawnWhitecloud();
    }

    // Update is called once per frame
    void Update()
    {
        if (timer < spawnRate)
        {
            timer = timer + Time.deltaTime;
        }
        else
        {
            spawnWhitecloud();
            timer = 0;
        }
    }

    void spawnWhitecloud()
    {
        float lowestPoint = transform.position.y - heightOffset;
        float highestPoint = transform.position.y + heightOffset;

        Instantiate(Whitecloud, new Vector3(transform.position.x, Random.Range(lowestPoint, highestPoint)), transform.rotation); 

    }
    
}
